// SCSS
import "./ctc.scss";

const Ctc = () => {
  return (
    <div className="ctc-search">
      <h5> CTC(LPA)</h5>
      <input type="text" placeholder="  Search" />
    </div>
  );
};

export default Ctc;
