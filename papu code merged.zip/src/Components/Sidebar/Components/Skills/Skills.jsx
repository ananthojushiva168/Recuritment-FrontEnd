// SCSS
import "./skills.scss";

const Skills = () => {
  return (
    <>
      <div className="skill-section">
        <h5>Skills</h5>
        <input type="text" placeholder="  Search skills" />
      </div>
    </>
  );
};

export default Skills;
