import React from 'react'

//SCSS
import "./forgotEmployer.scss"

const ForgotEmployer = () => {
  return (
    <div>ForgotEmployer</div>
  )
}

export default ForgotEmployer