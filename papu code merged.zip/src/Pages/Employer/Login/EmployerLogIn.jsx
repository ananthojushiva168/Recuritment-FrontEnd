//SCSS
import "./employerLogin.scss"

const EmployerLogIn = () => {
  return (
    <div>EmployerLogIn</div>
  )
}

export default EmployerLogIn