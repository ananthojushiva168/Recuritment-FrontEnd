//scss
import "./registerEmployer.scss"

const RegisterEmployer = () => {
  return (
    <div>RegisterEmployer</div>
  )
}

export default RegisterEmployer